## This is the simulation 1.0



* ### Runing this program

  ​	run *view.py* program

  

* ### In *resource*  file

  *map.txt* is the "2d array_map", *white2.png* is the background
  
  
  
* ### About the simulation animation

  *rea_point* means the people have been infected

  *green_point* means the people have not been infected

